package CONTROLES;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import GUIS.MENU;    // Importa el menú 1
import GUIS.MENU2;  // Importa el menú 2

import GUIS.INICIO; // Importa el inicio

public class Proyecto_Semaforos {

    private JFrame ventana;
    private CardLayout cardLayout;
    private JPanel panelPrincipal;

    public Proyecto_Semaforos() {
        initComponents();
    }

    private void initComponents() {
        // Crear la ventana principal sin decoración
        ventana = new JFrame("Proyecto Semáforos");
        ventana.setUndecorated(true);  // Sin barra de título ni botones predeterminados
        ventana.setSize(960, 640);
        ventana.setLocationRelativeTo(null);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear y añadir la barra superior personalizada
        JPanel barraSuperior = crearBarraSuperior();
        ventana.add(barraSuperior, BorderLayout.NORTH);

        // Instanciar paneles y agregar al CardLayout
        MENU panelMenu = new MENU();
        MENU2 panelMenu2 = new MENU2();
        INICIO panelInicio = new INICIO(); // Instancia de INICIO

        // Crear el CardLayout y añadir los menús al panel principal
        cardLayout = new CardLayout();
        panelPrincipal = new JPanel(cardLayout);
        panelPrincipal.add(new MENU(), "Menu");
        panelPrincipal.add(new MENU2(), "Menu2");

        panelPrincipal.add(new INICIO(), "Inicio");  // Agrega CALLE1 al panel principal

        ventana.add(panelPrincipal, BorderLayout.CENTER);
        ventana.setVisible(true);

        // Mostrar el primer menú (MENU) por defecto
        mostrarMenu("Menu"); //Cambiar por Menu
    }

    private JPanel crearBarraSuperior() {
        JPanel barraSuperior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        barraSuperior.setBackground(Color.DARK_GRAY);
        barraSuperior.setPreferredSize(new Dimension(ventana.getWidth(), 50));

        // Crear botones de control
        JButton btnCerrar = crearBotonControl("X", Color.RED, e -> cerrarVentana());
        JButton btnMaximizar = crearBotonControl("▢", Color.GRAY, e -> maximizarRestaurarVentana());
        JButton btnMinimizar = crearBotonControl("-", Color.GRAY, e -> minimizarVentana());

        JButton btnIrMenu = crearBotonControl("MENU", Color.GREEN, e -> mostrarMenu("Menu"));     // Botón para ir a MENU
        JButton btnIrInicio = crearBotonControl("INICIO", Color.BLACK, e -> mostrarMenu("Inicio"));     // Botón para ir a MENU

        // Añadir los botones a la barra superior
        barraSuperior.add(btnIrMenu);   // Botón para cambiar a MENU
        barraSuperior.add(btnIrInicio);
        

        barraSuperior.add(btnMinimizar);
        //barraSuperior.add(btnMaximizar);
        barraSuperior.add(btnCerrar);

        return barraSuperior;
    }

    private JButton crearBotonControl(String texto, Color colorFondo, java.awt.event.ActionListener accion) {
        JButton boton = new JButton(texto);
        boton.setPreferredSize(new Dimension(110, 50));
        boton.setFont(new Font("Arial", Font.BOLD, 20));
        boton.setBackground(colorFondo);
        boton.setForeground(Color.WHITE);
        boton.setBorder(BorderFactory.createEmptyBorder());
        boton.setFocusPainted(false);
        boton.addActionListener(accion);
        return boton;
    }

    private void mostrarMenu(String nombreMenu) {
        cardLayout.show(panelPrincipal, nombreMenu);
    }

    private void cerrarVentana() {
        System.exit(0);  // Cerrar la aplicación
    }

    private void maximizarRestaurarVentana() {
        if (ventana.getExtendedState() == JFrame.MAXIMIZED_BOTH) {
            ventana.setExtendedState(JFrame.NORMAL);
            ventana.setSize(960, 640);
            ventana.setLocationRelativeTo(null);
            mostrarMenu("Menu");  // Mostrar MENU en tamaño normal
        } else {
            ventana.setExtendedState(JFrame.MAXIMIZED_BOTH);
            mostrarMenu("Menu2");  // Mostrar MENU2 en modo maximizado
        }
    }

    private void minimizarVentana() {
        ventana.setState(JFrame.ICONIFIED);  // Minimizar la ventana
    }

    public static void main(String[] args) {
        new Proyecto_Semaforos();
    }
}
