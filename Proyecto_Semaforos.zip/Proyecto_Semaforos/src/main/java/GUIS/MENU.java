package GUIS;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class MENU extends javax.swing.JPanel {

    private JLabel imagenCarrito;
    private JLabel imagenCarrito2;
    private int xPos = 950;  // Posición inicial para el primer carrito
    private int xPos2 = -280; // Posición inicial para el segundo carrito
    private JLabel tituloLabel;
    private Color colorRojo = Color.RED;
    private Color colorAmarillo = Color.YELLOW;
    private Color colorVerde = Color.GREEN;
    private int estadoSemaforo = 0; // 0: Rojo, 1: Amarillo, 2: Verde
    private Timer timer;
    private Timer timerSemaforo; // Temporizador para el semáforo

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Dibuja tres cuadros de color gris claro
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(0, 0, 1000, 90);  // Primer cuadro
        g.fillRect(0, 240, 1000, 100); // Segundo cuadro
        g.fillRect(0, 490, 1000, 100); // Tercer cuadro

        g.setColor(Color.WHITE); // Cambia el color a blanco
        g.fillRect(0, 168, 1000, 3); // Cuadrado adicional 1
        g.fillRect(0, 410, 1000, 3); // Cuadrado adicional 2

        // Dibuja el semáforo en horizontal
        g.setColor(Color.BLACK); // Color del marco del semáforo
        g.fillRect(400, 20, 180, 60); // Marco del semáforo (más ancho)

        // Dibuja los círculos
        int xPos = 404; // Posición horizontal inicial
        int diameter = 50; // Diámetro de los círculos
        int yOffset = 5; // Desplazamiento vertical para centrar los círculos

        // Dibuja el círculo rojo
        g.setColor(estadoSemaforo == 0 ? colorRojo : Color.DARK_GRAY); // Rojo si está activo
        g.fillOval(xPos, 19 + yOffset, diameter, diameter); // Círculo rojo

        // Dibuja el círculo amarillo
        g.setColor(estadoSemaforo == 1 ? colorAmarillo : Color.DARK_GRAY); // Amarillo si está activo
        g.fillOval(xPos + 60, 19 + yOffset, diameter, diameter); // Círculo amarillo

        // Dibuja el círculo verde
        g.setColor(estadoSemaforo == 2 ? colorVerde : Color.DARK_GRAY); // Verde si está activo
        g.fillOval(xPos + 120, 19 + yOffset, diameter, diameter); // Círculo verde
    }

    /**
     * Creates new form INIC
     */
    public MENU() {
        initComponents();
        cargarImagenCarrito();
        cargarImagenCarrito2();
        configurarTitulo();  // Configura el título

        // Temporizador para mover los carritos
        Timer timerCarritos = new Timer(30, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moverImagen();  // Llama al método de movimiento en cada tick del timer
            }
        });
        timerCarritos.start();  // Inicia el temporizador para carritos

        // Temporizador para el semáforo
        timerSemaforo = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                estadoSemaforo = (estadoSemaforo + 1) % 3; // Cambia el estado del semáforo
                repaint(); // Vuelve a pintar el panel
            }
        });
        timerSemaforo.start(); // Inicia el temporizador del semáforo
    }

    private void cargarImagenCarrito() {
        File file = new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarritoAm1_1.png");
        ImageIcon imageIcon = new ImageIcon(file.getAbsolutePath());
        Image imagen = imageIcon.getImage().getScaledInstance(300, 200, Image.SCALE_SMOOTH);
        imagenCarrito = new JLabel(new ImageIcon(imagen));
        imagenCarrito.setBounds(xPos, 100, 300, 200); // Establece la posición inicial del primer carrito
        this.add(imagenCarrito);
    }

    private void cargarImagenCarrito2() {
        File file = new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarritoRos1_1.png");
        ImageIcon imageIcon = new ImageIcon(file.getAbsolutePath());
        Image imagen = imageIcon.getImage().getScaledInstance(300, 200, Image.SCALE_SMOOTH);
        imagenCarrito2 = new JLabel(new ImageIcon(imagen));
        imagenCarrito2.setBounds(xPos2, 350, 300, 200); // Establece la posición inicial del segundo carrito
        this.add(imagenCarrito2);
    }

    private void moverImagen() {
        // Mueve el primer carrito hacia la izquierda
        xPos -= 2;
        imagenCarrito.setBounds(xPos, 70, 300, 200);

        if (xPos <= -300) {  // Si el primer carrito sale por la izquierda, reinicia a la derecha
            xPos = getWidth();
        }

        // Mueve el segundo carrito hacia la derecha
        xPos2 += 2;
        imagenCarrito2.setBounds(xPos2, 312, 300, 200);

        if (xPos2 >= getWidth()) {  // Si el segundo carrito sale por la derecha, reinicia a la izquierda
            xPos2 = -300;
        }

        repaint();
    }

    private void configurarTitulo() {
        // Crea el JLabel para el título
        tituloLabel = new JLabel("Proyecto Semaforos");

        // Configura la fuente, estilo y tamaño
        tituloLabel.setFont(new Font("Arial", Font.BOLD, 44));
        tituloLabel.setForeground(Color.BLACK); // Puedes cambiar el color aquí

        // Posición central en la parte superior (ajustable según tus preferencias)
        tituloLabel.setBounds(200, 270, 600, 50);  // Ajusta el tamaño y posición como necesites

        // Alineación del texto dentro del JLabel
        tituloLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Añade el título al panel
        this.setLayout(null);  // Para usar setBounds, el layout debe ser nulo
        this.add(tituloLabel);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 683, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 378, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
