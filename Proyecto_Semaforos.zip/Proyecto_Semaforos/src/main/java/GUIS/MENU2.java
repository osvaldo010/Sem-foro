package GUIS;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MENU2 extends javax.swing.JPanel {

    private int x = 0;  // Coordenada x de la imagen
    private int y = 500;  // Coordenada y de la imagen
    private int pantallaAncho = 960;
    private int pantallaAlto = 640;
    private JLabel imagenCarrito;
    private JLabel imagenCarrito2;
    private int yPos = 500; // Inicial posición Y
    private int yPos2 = -700;  // Inicial posición Y para el segundo carro
    private final Timer timer; // Timer para mover la imagen
    
    public MENU2() {
        initComponents();
        ajustarComponentes();
        // Configurar el Timer que mueve la imagen cada 10 milisegundos
        timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moverImagen();
            }
        });
        timer.start(); // Iniciar el movimiento
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Titulo = new javax.swing.JLabel();
        btnIni = new javax.swing.JButton();
        btnOpc = new javax.swing.JButton();
        btnSal = new javax.swing.JButton();

        setBackground(new java.awt.Color(102, 102, 102));
        setForeground(new java.awt.Color(255, 255, 255));

        Titulo.setBackground(new java.awt.Color(0, 0, 0));
        Titulo.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setText("SIMULADOR SEMAFOROS");

        btnIni.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnIni.setText("INICIO");

        btnOpc.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnOpc.setText("OPCIONES");

        btnSal.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnSal.setText("SALIR");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(70, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(Titulo)
                        .addGap(62, 62, 62))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnOpc, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnIni, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSal, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(288, 288, 288))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(Titulo)
                .addGap(37, 37, 37)
                .addComponent(btnIni, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(btnOpc, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(btnSal, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(64, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Titulo;
    private javax.swing.JButton btnIni;
    private javax.swing.JButton btnOpc;
    private javax.swing.JButton btnSal;
    // End of variables declaration//GEN-END:variables

    private void ajustarComponentes() {
         // Establecer layout nulo para poder usar coordenadas absolutas
    // Establecer layout nulo para poder usar coordenadas absolutas
    this.setLayout(null);

    // Obtener las dimensiones de la pantalla completa
    int pantallaAncho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
    int pantallaAlto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;

    // Ajustar el Título con coordenadas absolutas y centrarlo
    Titulo.setBounds((pantallaAncho - 600) / 2, 50, 700, 80);  // x, y, width, height
    this.add(Titulo);

    // Ajustar el botón "INICIO" con coordenadas absolutas y centrarlo
    btnIni.setBounds((pantallaAncho - 290) / 2, 250, 300, 120);  // x, y, width, height
    btnIni.setBackground(new java.awt.Color(255, 255, 255)); // Botón blanco
    btnIni.setForeground(new java.awt.Color(0, 0, 0)); // Texto en negro
    this.add(btnIni);

    // Ajustar el botón "OPCIONES" con coordenadas absolutas y centrarlo
    btnOpc.setBounds((pantallaAncho - 290) / 2, 550, 300, 120);  // x, y, width, height
    btnOpc.setBackground(new java.awt.Color(255, 255, 255)); // Botón blanco
    btnOpc.setForeground(new java.awt.Color(0, 0, 0)); // Texto en negro
    this.add(btnOpc);

    // Ajustar el botón "SALIR" con coordenadas absolutas y centrarlo
    btnSal.setBounds((pantallaAncho - 290) / 2, 850, 300, 120);  // x, y, width, height
    btnSal.setBackground(new java.awt.Color(255, 255, 255)); // Botón blanco
    btnSal.setForeground(new java.awt.Color(0, 0, 0)); // Texto en negro
    this.add(btnSal);

    // Crear y agregar el primer cuadrado blanco (ajustado para pantalla completa)
    JPanel cuadrado1 = new JPanel();
    cuadrado1.setBackground(new java.awt.Color(255, 255, 255)); // Fondo blanco
    cuadrado1.setBounds(40, 0, 80, pantallaAlto);  // x, y, width, height
    this.add(cuadrado1);

    // Crear y agregar el segundo cuadrado blanco (ajustado para pantalla completa)
    JPanel cuadrado2 = new JPanel();
    cuadrado2.setBackground(new java.awt.Color(255, 255, 255)); // Fondo blanco
    cuadrado2.setBounds(pantallaAncho - 120, 0, 80, pantallaAlto);  // x, y, width, height
    this.add(cuadrado2);
    
    cargarImagenCarrito();
    cargarImagenCarrito2();
    }
    
    private void cargarImagenCarrito() {
    File file = new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarritoAm1.png");
    ImageIcon imageIcon = new ImageIcon(file.getAbsolutePath());
    
    // Cambiar el tamaño de la imagen a 200x200 (puedes ajustar según tus necesidades)
    Image imagen = imageIcon.getImage().getScaledInstance(400, 700, Image.SCALE_SMOOTH);
    
    imagenCarrito = new JLabel(new ImageIcon(imagen));
    
    // Establecer posición inicial con las nuevas dimensiones
    imagenCarrito.setBounds(600, yPos, 400, 700); // Ajusta el tamaño en el setBounds también
    this.add(imagenCarrito);
}
    
    private void cargarImagenCarrito2() {
        File file = new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarritoRos1.png");
        ImageIcon imageIcon = new ImageIcon(file.getAbsolutePath());
        Image imagen = imageIcon.getImage().getScaledInstance(400, 700, Image.SCALE_SMOOTH);
        imagenCarrito2 = new JLabel(new ImageIcon(imagen));
        imagenCarrito2.setBounds(150, yPos2, 400, 700);
        this.add(imagenCarrito2);
    }
    
    // Método para mover la imagen
    private void moverImagen() {
        // Incrementar la posición Y
        yPos -= 2;  // Cambia el valor para ajustar la velocidad del movimiento
        imagenCarrito.setBounds(1250, yPos, 400, 700);  // Mantén X=600 y actualiza Y
        
        // Si la imagen llega al borde inferior, reinicia la posición
        if (yPos <= -550) {
        yPos = getHeight(); // Reinicia la posición al borde inferior
        }
        
        // Mover el segundo carro hacia abajo
        yPos2 += 2;
        imagenCarrito2.setBounds(250, yPos2, 400, 700);
        if (yPos2 >= getHeight()) {
            yPos2 = -550;
        }
    }
}
