package GUIS;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import java.util.Random;

/**
 *
 * @author Joshua
 */
public class INICIO extends javax.swing.JPanel {

    private int limiteParadaCarrito1 = 390; // Límite de parada para el carrito 1 (eje y)
    private int limiteParadaCarrito2 = 500; // Límite de parada para el carrito 2 (eje x)
    private int estadoSemaforo1 = 0; // Estado del primer semáforo (0: Rojo, 1: Amarillo, 2: Verde)
    private int estadoSemaforo2 = 2; // Estado del segundo semáforo (inicialmente Verde)
    private Color colorRojo = Color.RED;
    private Color colorAmarillo = Color.YELLOW;
    private Color colorVerde = Color.GREEN;
    private int velocidadSemaforo1 = 12000; // Velocidad inicial del semáforo 1
    private int velocidadSemaforo2 = 12000; // Velocidad inicial del semáforo 2
    private JLabel lblModificarVelocidad;
    private JLabel imagenCarrito;
    private JLabel imagenCarrito2;
    //Movimiento carros
    private Timer timer;
    private int xPosCarrito1 = 320; // Posición inicial del carrito 1 (hacia arriba)
    private int yPosCarrito1 = 600; // Posición inicial del carrito 1
    private int xPosCarrito2 = 900; // Posición inicial del carrito 2 (hacia la izquierda)
    private int yPosCarrito2 = 230; // Posición inicial del carrito 2
    private final int MARCA_CARRO1 = -500; // Marca para el carrito 1 (arriba)
    private final int MARCA_CARRO2 = -500; // Marca para el carrito 2 (izquierda)
    private final int VELOCIDAD_CARRO = 10; // Velocidad de movimiento de los carritos
    private final int MARCADOR_LIMITE_FINAL_X = -400;
    private final int MARCADOR_LIMITE_FINAL_Y = -600;
    private Random random = new Random();

    private int contadorCarro1 = 0;
    private int contadorCarro2 = 0;
    private int LIMITE_PASADAS_CARRO1 = 1; // Define el límite de pasadas para el carrito 1
    private int LIMITE_PASADAS_CARRO2 = 1; // Define el límite de pasadas para el carrito 2
    private boolean carrito1PasoLimite = false; // Marca si el carrito 1 pasó el límite de parada
    private boolean carrito2PasoLimite = false; // Marca si el carrito 2 pasó el límite de parada
    private JLabel labelCarritos; // Etiqueta para mostrar la cantidad de carritos

    private JLabel labelLimiteCarro1;
    private JLabel labelLimiteCarro2;

    public INICIO() {
        initComponents();
        setLayout(null); // Necesario para usar setBounds
        cargarImagenCarrito(); // Carga el primer carrito
        cargarImagenCarrito2(); // Carga el segundo carrito
        // Inicia el timer para mover los carrito
        configurarTitulo(); // Llama al método para configurar el título
        initCustomComponents(); // Llama a la función de configuración personalizada
        initCustomComponents1(); // Llama a la función de configuración personalizada
        new Thread(() -> {
            while (true) {
                try {
                    // Primer semáforo en Rojo, segundo en Verde
                    estadoSemaforo1 = 0; // Rojo para el primer semáforo
                    estadoSemaforo2 = 2; // Verde para el segundo semáforo
                    repaint(); // Redibuja los semáforos
                    Thread.sleep(velocidadSemaforo1); // Espera según la velocidad del semáforo 1

                    // Primer semáforo en Amarillo, segundo en Rojo
                    estadoSemaforo1 = 1; // Amarillo para el primer semáforo
                    estadoSemaforo2 = 0; // Rojo para el segundo semáforo
                    repaint(); // Redibuja los semáforos
                    Thread.sleep(1000); // Espera 1 segundo

                    // Primer semáforo en Verde, segundo en Rojo
                    estadoSemaforo1 = 2; // Verde para el primer semáforo
                    estadoSemaforo2 = 0; // Rojo para el segundo semáforo
                    repaint(); // Redibuja los semáforos
                    Thread.sleep(velocidadSemaforo1); // Espera según la velocidad del semáforo 1

                    // Primer semáforo en Rojo, segundo en Amarillo
                    estadoSemaforo1 = 0; // Rojo para el primer semáforo
                    estadoSemaforo2 = 1; // Amarillo para el segundo semáforo
                    repaint(); // Redibuja los semáforos
                    Thread.sleep(1000); // Espera 1 segundo
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void initCustomComponents1() {
        // Cargar casas con coordenadas y tamaños individuales
        cargarImagenCasa("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/Casa1.png", 120, 0, 70, 70);   // Casa 1 en (100, 100) con 150x150
        cargarImagenCasa("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/Casa2.png", 760, 0, 200, 80);  // Casa 2 en (0, 0) con 200x250
        cargarImagenCasa("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/Casa3.png", 0, 500, 180, 120);  // Casa 3 en (550, 200) con 180x220
        cargarImagenCasa("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/Casa4.png", 0, 0, 80, 130);  // Casa 4 en (800, 250) con 160x160
    }

    private File[] carritos1 = {
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarritoAm1.png"),
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarroBl1.png"),
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarroGr1.png"),
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarroNe1.png"),
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarroRo1.png")
    };

    private File[] carritos2 = {
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarritoRos1.png"),
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarritoAm1_1.png"),
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarroNe1_1.png"),
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarroBl1_1.png"),
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarroGr1_1.png"),
        new File("C:/Users/Joshua/Documents/NetBeansProjects/Proyecto_Semaforos/src/main/java/IMAGENES/CarroRo1_1.png")

    };

// Métodos para establecer la velocidad de los semáforos
    // Método para configurar componentes personalizados
    private void initCustomComponents() {
        // Crear botones para modificar la velocidad
        javax.swing.JButton btnSpeedUp = new javax.swing.JButton("-");
        javax.swing.JButton btnSpeedDown = new javax.swing.JButton("+");

        // Configurar el color de los botones
        btnSpeedUp.setBackground(new java.awt.Color(51, 51, 51)); // Gris oscuro
        btnSpeedDown.setBackground(new java.awt.Color(51, 51, 51)); // Gris oscuro

        btnSpeedUp.setForeground(java.awt.Color.WHITE); // Texto blanco
        btnSpeedDown.setForeground(java.awt.Color.WHITE); // Texto blanco
        JButton btnStart = new JButton("Start");

        // Configurar el botón (tamaño, posición y color)
        btnStart.setBounds(700, 552, 80, 30);  // Ajusta posición y tamaño según tu interfaz
        btnStart.setBackground(new java.awt.Color(51, 51, 51));  // Color gris
        btnStart.setForeground(Color.WHITE);  // Texto blanco

        // Configurar el layout absoluto
        setLayout(null); // Desactivar el layout manager

        // Añadir lo relacionado a etxt
        // Inicializa los JLabels
        labelLimiteCarro1 = new JLabel(String.valueOf(LIMITE_PASADAS_CARRO1));
        labelLimiteCarro2 = new JLabel(String.valueOf(LIMITE_PASADAS_CARRO2));

        // Configura la fuente y el tamaño
        labelLimiteCarro1.setFont(new Font("Arial", Font.BOLD, 16));
        labelLimiteCarro2.setFont(new Font("Arial", Font.BOLD, 16));

        // Establece la posición y añade a la ventana
        labelLimiteCarro1.setBounds(540, 450, 100, 50); // Ajusta según necesites
        labelLimiteCarro2.setBounds(540, 500, 100, 50); // Ajusta según necesites

        this.add(labelLimiteCarro1);
        this.add(labelLimiteCarro2);
        // Establecer tamaño y posición de los botones
        btnSpeedUp.setBounds(880, 410, 50, 30); // X, Y, Ancho, Alto
        btnSpeedDown.setBounds(800, 410, 50, 30); // X, Y, Ancho, Alto

        // Añadir botones a la ventana
        add(btnSpeedUp);
        add(btnSpeedDown);
        add(btnStart);

        // Añadir acción al botón para iniciar el movimiento de los carritos
        btnStart.addActionListener(evt -> {
            iniciarTimer();
        });

        // Añadir lógica de eventos a los botones
        btnSpeedUp.addActionListener(evt -> adjustSpeed(1000)); // Aumentar velocidad
        btnSpeedDown.addActionListener(evt -> adjustSpeed(-1000)); // Disminuir velocidad

        // Crear botones para modificar el límite de pasadas
        javax.swing.JButton btnIncreaseCar1 = new javax.swing.JButton("+");
        javax.swing.JButton btnDecreaseCar1 = new javax.swing.JButton("-");
        javax.swing.JButton btnIncreaseCar2 = new javax.swing.JButton("+");
        javax.swing.JButton btnDecreaseCar2 = new javax.swing.JButton("-");

// Configurar el color de los botones
        btnIncreaseCar1.setBackground(new java.awt.Color(51, 51, 51));
        btnDecreaseCar1.setBackground(new java.awt.Color(51, 51, 51));
        btnIncreaseCar2.setBackground(new java.awt.Color(51, 51, 51));
        btnDecreaseCar2.setBackground(new java.awt.Color(51, 51, 51));
        btnIncreaseCar1.setForeground(java.awt.Color.WHITE);
        btnDecreaseCar1.setForeground(java.awt.Color.WHITE);
        btnIncreaseCar2.setForeground(java.awt.Color.WHITE);
        btnDecreaseCar2.setForeground(java.awt.Color.WHITE);

// Configurar el layout absoluto
        setLayout(null); // Desactivar el layout manager

// Establecer tamaño y posición de los botones
        btnIncreaseCar1.setBounds(750, 460, 50, 30); // Posición y tamaño para carrito 1
        btnDecreaseCar1.setBounds(810, 460, 50, 30);
        btnIncreaseCar2.setBounds(750, 510, 50, 30); // Posición y tamaño para carrito 2
        btnDecreaseCar2.setBounds(810, 510, 50, 30);

// Añadir botones a la ventana
        add(btnIncreaseCar1);
        add(btnDecreaseCar1);
        add(btnIncreaseCar2);
        add(btnDecreaseCar2);

// Añadir lógica de eventos a los botones
        // Añadir lógica de eventos a los botones
        btnIncreaseCar1.addActionListener(evt -> {
            modificarLimitePasadasCarro1(1); // Aumentar pasadas para carro 1
            actualizarLimites(); // Actualiza el JLabel
        });

        btnDecreaseCar1.addActionListener(evt -> {
            modificarLimitePasadasCarro1(-1); // Disminuir pasadas para carro 1
            actualizarLimites(); // Actualiza el JLabel
        });

        btnIncreaseCar2.addActionListener(evt -> {
            modificarLimitePasadasCarro2(1); // Aumentar pasadas para carro 2
            actualizarLimites(); // Actualiza el JLabel
        });

        btnDecreaseCar2.addActionListener(evt -> {
            modificarLimitePasadasCarro2(-1); // Disminuir pasadas para carro 2
            actualizarLimites(); // Actualiza el JLabel
        });

    }

    private void actualizarLimites() {
        labelLimiteCarro1.setText(String.valueOf(LIMITE_PASADAS_CARRO1));
        labelLimiteCarro2.setText(String.valueOf(LIMITE_PASADAS_CARRO2));
    }

    // Métodos para ajustar el límite de pasadas
    private void modificarLimitePasadasCarro1(int cambio) {
        LIMITE_PASADAS_CARRO1 = Math.max(0, LIMITE_PASADAS_CARRO1 + cambio); // Evita valores negativos
    }

    private void modificarLimitePasadasCarro2(int cambio) {
        LIMITE_PASADAS_CARRO2 = Math.max(0, LIMITE_PASADAS_CARRO2 + cambio); // Evita valores negativos
    }

    private void adjustSpeed(int delta) {
        // Ajustar velocidad de ambos semáforos
        velocidadSemaforo1 = Math.max(1000, velocidadSemaforo1 + delta); // Limitar a un mínimo de 1000 ms
        velocidadSemaforo2 = Math.max(1000, velocidadSemaforo2 + delta); // Limitar a un mínimo de 1000 ms

        System.out.println("Nueva velocidad Semáforo 1: " + velocidadSemaforo1 + " ms");
        System.out.println("Nueva velocidad Semáforo 2: " + velocidadSemaforo2 + " ms");

        // Aquí podrías agregar lógica para aplicar la nueva velocidad a los semáforos
    }

    private void cargarImagenCarrito() {
        // Seleccionar un índice aleatorio para el carrito 1
        int indiceAleatorio = random.nextInt(carritos1.length); // Genera un número aleatorio entre 0 y la longitud del array - 1

        ImageIcon imageIcon = new ImageIcon(carritos1[indiceAleatorio].getAbsolutePath());
        Image imagen = imageIcon.getImage().getScaledInstance(200, 300, Image.SCALE_SMOOTH);
        imagenCarrito = new JLabel(new ImageIcon(imagen));
        imagenCarrito.setBounds(xPosCarrito1, yPosCarrito1, 200, 300); // Establece la posición inicial del carrito 1
        this.add(imagenCarrito);
    }

    private void cargarImagenCarrito2() {
        // Seleccionar un índice aleatorio para el carrito 2
        int indiceAleatorio = random.nextInt(carritos2.length); // Genera un número aleatorio entre 0 y la longitud del array - 1

        ImageIcon imageIcon = new ImageIcon(carritos2[indiceAleatorio].getAbsolutePath());
        Image imagen = imageIcon.getImage().getScaledInstance(300, 200, Image.SCALE_SMOOTH);
        imagenCarrito2 = new JLabel(new ImageIcon(imagen));
        imagenCarrito2.setBounds(xPosCarrito2, yPosCarrito2, 300, 200); // Establece la posición inicial del carrito 2
        this.add(imagenCarrito2);
    }

    private void cargarImagenCasa(String ruta, int x, int y, int ancho, int alto) {
        File file = new File(ruta);
        ImageIcon imageIcon = new ImageIcon(file.getAbsolutePath());
        Image imagen = imageIcon.getImage().getScaledInstance(ancho, alto, Image.SCALE_SMOOTH); // Ajusta el tamaño según el ancho y alto proporcionados
        JLabel imagenCasa = new JLabel(new ImageIcon(imagen));
        imagenCasa.setBounds(x, y, ancho, alto); // Establece la posición y tamaño de la casa
        this.add(imagenCasa); // Añade el JLabel a la ventana
    }

    private void moverCarritos() {
        // Movimiento del carrito 1 (hacia arriba)

        if (contadorCarro1 < LIMITE_PASADAS_CARRO1 || yPosCarrito1 > MARCADOR_LIMITE_FINAL_Y) {
            if (estadoSemaforo1 == 2 || (estadoSemaforo1 == 0 && yPosCarrito1 > limiteParadaCarrito1)) {
                yPosCarrito1 -= VELOCIDAD_CARRO; // Mueve el carrito hacia arriba
            } else if (estadoSemaforo1 == 0 && yPosCarrito1 <= limiteParadaCarrito1) {
                yPosCarrito1 = limiteParadaCarrito1; // Asegura que el carrito se detiene en el límite de parada
            }

            // Detecta cuando el carrito pasa por el límite de parada y aumenta el contador
            if (yPosCarrito1 <= limiteParadaCarrito1 && !carrito1PasoLimite) {
                carrito1PasoLimite = true;
                contadorCarro1++;
            }

            // Si el carrito alcanza el marcador límite final después del límite de pasadas
            if (contadorCarro1 >= LIMITE_PASADAS_CARRO1 && yPosCarrito1 <= MARCADOR_LIMITE_FINAL_Y) {
                // El carrito desaparece al pasar el marcador límite final
                yPosCarrito1 = MARCADOR_LIMITE_FINAL_Y;
            } else if (yPosCarrito1 <= MARCA_CARRO1 && contadorCarro1 < LIMITE_PASADAS_CARRO1) {
                // Reinicia el carrito para seguir moviéndose si aún no ha llegado al límite de pasadas
                yPosCarrito1 = 600;
                carrito1PasoLimite = false;
            }

            // Actualiza la posición del carrito
            imagenCarrito.setBounds(xPosCarrito1, yPosCarrito1, 200, 300);
        } else {
            // Si ha llegado al límite, mantén el carrito en su posición final inmóvil
            yPosCarrito1 = MARCADOR_LIMITE_FINAL_Y;
            imagenCarrito.setBounds(xPosCarrito1, yPosCarrito1, 200, 300);
        }

        // Movimiento del carrito 2 (hacia la izquierda)
        if (contadorCarro2 < LIMITE_PASADAS_CARRO2 || xPosCarrito2 > MARCADOR_LIMITE_FINAL_X) {
            if (estadoSemaforo2 == 2 || (estadoSemaforo2 == 0 && xPosCarrito2 > limiteParadaCarrito2)) {
                xPosCarrito2 -= VELOCIDAD_CARRO; // Mueve el carrito hacia la izquierda
            } else if (estadoSemaforo2 == 0 && xPosCarrito2 <= limiteParadaCarrito2) {
                xPosCarrito2 = limiteParadaCarrito2;
            }

            // Detecta cuando el carrito pasa por el límite de parada y aumenta el contador
            if (xPosCarrito2 <= limiteParadaCarrito2 && !carrito2PasoLimite) {
                carrito2PasoLimite = true;
                contadorCarro2++;
            }

            // Si el carrito alcanza el marcador límite final después del límite de pasadas
            if (contadorCarro2 >= LIMITE_PASADAS_CARRO2 && xPosCarrito2 <= MARCADOR_LIMITE_FINAL_X) {
                // El carrito desaparece al pasar el marcador límite final
                xPosCarrito2 = MARCADOR_LIMITE_FINAL_X;
            } else if (xPosCarrito2 <= MARCA_CARRO2 && contadorCarro2 < LIMITE_PASADAS_CARRO2) {
                // Reinicia el carrito para seguir moviéndose si aún no ha llegado al límite de pasadas
                xPosCarrito2 = 1000;
                carrito2PasoLimite = false;
            }

            // Actualiza la posición del carrito
            imagenCarrito2.setBounds(xPosCarrito2, yPosCarrito2, 300, 200);
        } else {
            // Si ha llegado al límite, mantén el carrito en su posición final inmóvil
            xPosCarrito2 = MARCADOR_LIMITE_FINAL_X;
            imagenCarrito2.setBounds(xPosCarrito2, yPosCarrito2, 300, 200);
        }

        // Redibuja la interfaz
        this.repaint();
    }

    private void iniciarTimer() {
        timer = new Timer(10, e -> moverCarritos()); // Llama a moverCarritos cada 100 ms
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); // Llama al método padre para limpiar el panel

        // Dibuja la línea del límite de parada para el carrito 1 (eje y)
        g.setColor(Color.RED);
        g.drawLine(xPosCarrito1, limiteParadaCarrito1, xPosCarrito1 + 200, limiteParadaCarrito1);
        g.drawString("Límite de parada carrito 1", xPosCarrito1, limiteParadaCarrito1 - 5);

        // Dibuja la línea del límite de parada para el carrito 2 (eje x)
        g.setColor(Color.BLUE);
        g.drawLine(limiteParadaCarrito2, yPosCarrito2, limiteParadaCarrito2, yPosCarrito2 + 200);
        g.drawString("Límite de parada carrito 2", limiteParadaCarrito2 - 40, yPosCarrito2 + 15);
        // Dibuja tres rectángulos
        g.setColor(Color.LIGHT_GRAY); // Color del primer rectángulo
        g.fillRect(0, 0, 200, 140); // Primer rectángulo
        g.fillRect(0, 390, 200, 200); // Segundo rectángulo
        g.fillRect(500, 0, 600, 140); // Tercer rectángulo
        g.fillRect(500, 390, 600, 200); // Cuarto rectángulo

        g.setColor(Color.WHITE); // Cambia el color a blanco
        g.fillRect(0, 260, 1000, 8); // Cuadrado adicional 1
        g.fillRect(340, 0, 8, 800); // Cuadrado adicional 2

        // Dibuja el primer semáforo (horizontal)
        g.setColor(Color.BLACK); // Color del marco del primer semáforo
        g.fillRect(80, 390, 120, 60); // Marco del primer semáforo

        // Dibuja los círculos del primer semáforo
        int xPos1 = 98; // Posición horizontal inicial del primer semáforo
        int diameter = 20; // Diámetro de los círculos
        int yOffset = 382; // Desplazamiento vertical para centrar los círculos

        // Dibuja el círculo rojo del primer semáforo
        g.setColor(estadoSemaforo1 == 0 ? colorRojo : Color.DARK_GRAY); // Rojo si está activo
        g.fillOval(xPos1, 24 + yOffset, diameter, diameter); // Círculo rojo

        // Dibuja el círculo amarillo del primer semáforo
        g.setColor(estadoSemaforo1 == 1 ? colorAmarillo : Color.DARK_GRAY); // Amarillo si está activo
        g.fillOval(xPos1 + 30, 24 + yOffset, diameter, diameter); // Círculo amarillo

        // Dibuja el círculo verde del primer semáforo
        g.setColor(estadoSemaforo1 == 2 ? colorVerde : Color.DARK_GRAY); // Verde si está activo
        g.fillOval(xPos1 + 60, 24 + yOffset, diameter, diameter); // Círculo verde

        // Dibuja el segundo semáforo (vertical)
        g.setColor(Color.BLACK); // Color del marco del segundo semáforo
        g.fillRect(500, 20, 60, 120); // Marco del segundo semáforo (vertical)

        // Dibuja los círculos del segundo semáforo
        int yPos2 = 38; // Posición vertical inicial del segundo semáforo
        int xPos2 = 520; // Posición horizontal inicial del primer semáforo
        // Dibuja el círculo rojo del segundo semáforo

        g.setColor(estadoSemaforo2 == 0 ? colorRojo : Color.DARK_GRAY); // Rojo si está activo
        g.fillOval(xPos2, yPos2, diameter, diameter); // Círculo rojo

        // Dibuja el círculo amarillo del segundo semáforo
        g.setColor(estadoSemaforo2 == 1 ? colorAmarillo : Color.DARK_GRAY); // Amarillo si está activo
        g.fillOval(xPos2, yPos2 + 30, diameter, diameter); // Círculo amarillo

        // Dibuja el círculo verde del segundo semáforo
        g.setColor(estadoSemaforo2 == 2 ? colorVerde : Color.DARK_GRAY); // Verde si está activo
        g.fillOval(xPos2, yPos2 + 60, diameter, diameter); // Círculo verde

        //Paso de zebra
        // Variables para el tamaño, separación y posición
        int rectWidth = 10;   // Ancho de cada rectángulo
        int rectHeight = 50;  // Alto de cada rectángulo
        int separation = 20;   // Separación entre los rectángulos
        int rectWidth2 = 50;   // Ancho de cada rectángulo
        int rectHeight2 = 10;  // Alto de cada rectángulo
        int separation2 = 0;   // Separación entre los rectángulos
        //Posición 4ta X y Y
        int startX = 219;      // Posición X inicial
        int startY1 = 390;    // Posición Y para la primera hilera
        //Posición 1er Y
        int startY3 = 90;      // Posición Y inicial
        //Posición 2da X
        int startX4 = 150;
        //Posición 3ra X y Y
        int startX2 = 500;    // Posición X inicial para la segunda hilera
        int startY2 = 145;    // Posición Y para la segunda hilera

        // Número de rectángulos a dibujar
        int numberOfRects = 10; // Puedes cambiar este valor para más o menos rectángulos

        //1ra
        // Dibuja la primera hilera de rectángulos
        for (int i = 0; i < numberOfRects; i++) {
            int xPos = startX + i * (rectWidth + separation); // Calcula la posición X de cada rectángulo
            g.setColor(Color.WHITE); // Establece el color del rectángulo
            g.fillRect(xPos, startY3, rectWidth, rectHeight); // Dibuja el rectángulo
        }
        //2da
        // Dibuja la segunda hilera de rectángulos (vertical)
        for (int i = 0; i < numberOfRects; i++) {
            int yPos = startY2 + i * (rectHeight - 25 + separation2); // Calcula la posición Y de cada rectángulo
            g.setColor(Color.WHITE); // Establece el color del rectángulo
            g.fillRect(startX4, yPos, rectWidth2, rectHeight2); // Dibuja el rectángulo
        }
        //3ra
        // Dibuja la segunda hilera de rectángulos (vertical)
        for (int i = 0; i < numberOfRects; i++) {
            int yPos = startY2 + i * (rectHeight - 25 + separation2); // Calcula la posición Y de cada rectángulo
            g.setColor(Color.WHITE); // Establece el color del rectángulo
            g.fillRect(startX2, yPos, rectWidth2, rectHeight2); // Dibuja el rectángulo
        }
        //4ta
        // Dibuja la primera hilera de rectángulos
        for (int i = 0; i < numberOfRects; i++) {
            int xPos = startX + i * (rectWidth + separation); // Calcula la posición X de cada rectángulo
            g.setColor(Color.WHITE); // Establece el color del rectángulo
            g.fillRect(xPos, startY1, rectWidth, rectHeight); // Dibuja el rectángulo
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBackground(new java.awt.Color(102, 102, 102));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void configurarTitulo() {
        // Crea el JLabel para el título
        JLabel tituloLabel = new JLabel("Modificar velocidad del semáforo:");
        JLabel cantidad1 = new JLabel("Carros vertical:");
        JLabel cantidad2 = new JLabel("Carros horizontal:");

        // Configura la fuente, estilo y tam+año
        tituloLabel.setFont(new Font("Arial", Font.BOLD, 16));
        tituloLabel.setForeground(Color.BLACK); // Puedes cambiar el color aquí

        cantidad1.setFont(new Font("Arial", Font.BOLD, 16));
        cantidad1.setForeground(Color.BLACK); // Puedes cambiar el color aquí

        cantidad2.setFont(new Font("Arial", Font.BOLD, 16));
        cantidad2.setForeground(Color.BLACK); // Puedes cambiar el color aquí

        // Posición central en la parte superior (ajustable según tus preferencias)
        tituloLabel.setBounds(360, 400, 600, 50); // Ajusta el tamaño y posición como necesites
        cantidad1.setBounds(360, 450, 600, 50);
        cantidad2.setBounds(350, 500, 600, 50);

        // Alineación del texto dentro del JLabel
        tituloLabel.setHorizontalAlignment(SwingConstants.CENTER);
        cantidad1.setHorizontalAlignment(SwingConstants.CENTER);
        cantidad2.setHorizontalAlignment(SwingConstants.CENTER);

        // Añade el título al panel
        this.setLayout(null); // Para usar setBounds, el layout debe ser nulo
        this.add(tituloLabel);
        this.add(cantidad1);
        this.add(cantidad2);
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
